package org.lnicholls.galleon.downloads;

/*
 * DownloadWork.java
 *
 * Created on 21 de abril de 2003, 05:52 PM
 */

public interface DownloadWork {

}
